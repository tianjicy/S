#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x200 - 0x200)
// BlueprintGeneratedClass BP_ActionDeath_SelfDestruct_SelfExplosion.BP_ActionDeath_SelfDestruct_SelfExplosion_C
class UBP_ActionDeath_SelfDestruct_SelfExplosion_C : public UBP_ActionDeath_SelfDestruct_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionDeath_SelfDestruct_SelfExplosion_C* GetDefaultObj();

};

}


