#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x20 (0x20 - 0x0)
// Function ALI_HumanCloth.ALI_HumanCloth_C.ClothLayer
struct IALI_HumanCloth_C_ClothLayer_Params
{
public:
	struct FPoseLink                             InPose;                                            // 0x0(0x10)(BlueprintVisible, BlueprintReadOnly, Parm, NoDestructor)
	struct FPoseLink                             ClothLayer;                                        // 0x10(0x10)(Parm, OutParm, NoDestructor)
};

}
}


