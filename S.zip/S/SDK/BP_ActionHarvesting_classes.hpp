#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x168 - 0x168)
// BlueprintGeneratedClass BP_ActionHarvesting.BP_ActionHarvesting_C
class UBP_ActionHarvesting_C : public UBP_ActionSimpleMonoMontage_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionHarvesting_C* GetDefaultObj();

};

}


