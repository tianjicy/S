#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x228 - 0x228)
// BlueprintGeneratedClass BP_ActionStep_Back.BP_ActionStep_Back_C
class UBP_ActionStep_Back_C : public UBP_ActionStepBase_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionStep_Back_C* GetDefaultObj();

};

}


