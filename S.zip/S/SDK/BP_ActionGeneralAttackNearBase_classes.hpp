#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x250 - 0x250)
// BlueprintGeneratedClass BP_ActionGeneralAttackNearBase.BP_ActionGeneralAttackNearBase_C
class UBP_ActionGeneralAttackNearBase_C : public UBP_ActionGeneralAttackBase_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionGeneralAttackNearBase_C* GetDefaultObj();

};

}


