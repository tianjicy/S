#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x168 - 0x168)
// BlueprintGeneratedClass BP_ActionMeleeSkill.BP_ActionMeleeSkill_C
class UBP_ActionMeleeSkill_C : public UBP_ActionSimpleMonoMontage_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionMeleeSkill_C* GetDefaultObj();

};

}


